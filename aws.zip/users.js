module.exports = [
    {
        id: 1,
        name: 'A',
        email: 'a@test.local'
    },
    {
        id: 2,
        name: 'B',
        email: 'b@test.local'
    },
    {
        id: 3,
        name: 'C',
        email: 'c@test.local'
    },
    {
        id: 4,
        name: 'D',
        email: 'd@test.local'
    },
    {
        id: 5,
        name: 'E',
        email: 'e@test.local'
    }
];