
module.exports = {
    IOT_ENPOINT: "a38xcgev8r5wez-ats.iot.us-east-1.amazonaws.com",
    IOT_TOPIC: "topic/test"
};